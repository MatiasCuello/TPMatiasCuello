﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeptunoSql.Windows.Helpers.Enum
{
    public enum Tipo
    {
        Success = 1,
        Error = 3

    }
}
